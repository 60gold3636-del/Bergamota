ui_print "- Bergamota Mi Zurna ringtone"
ui_print "- After reboot: Settings > Sounds > Ringtone > BergamotaMiZurna"
# Product partition copy is only needed when /product is separate
[ -d /product/media/audio/ringtones ] || rm -rf "$MODPATH/system/product"
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
